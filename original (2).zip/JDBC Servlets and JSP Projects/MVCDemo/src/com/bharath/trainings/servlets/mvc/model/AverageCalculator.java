package com.bharath.trainings.servlets.mvc.model;

public class AverageCalculator {

	public int calculate(int num1, int num2) {
		return (num1 + num2) / 2;
	}
}
